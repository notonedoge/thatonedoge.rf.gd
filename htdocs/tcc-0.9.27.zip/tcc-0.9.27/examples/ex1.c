#!/usr/local/bin/tcc -run
#include <tcclib.h>

int main()
{
    printf("Hello World\n");
    return 0;
}
